﻿using IdeaPortal.Data;
using IdeaPortal.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace IdeaPortal.Controllers
{
    public class UsersController : Controller
    {
        private readonly DatabaseContext dbContext;

        public UsersController(DatabaseContext dbContext)
        {
            this.dbContext = dbContext;
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var users = await dbContext.Users.ToListAsync();
            return View(users); 
        }

        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Add(User addUserRequest)
        {
            await dbContext.Users.AddAsync(addUserRequest);
            await dbContext.SaveChangesAsync();
            return RedirectToAction("Add");
        }
    }
}
