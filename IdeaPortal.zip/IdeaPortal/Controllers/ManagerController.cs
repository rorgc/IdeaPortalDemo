﻿using Microsoft.AspNetCore.Mvc;

namespace IdeaPortal.Controllers
{
    public class ManagerController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
