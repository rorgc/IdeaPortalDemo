﻿using Microsoft.AspNetCore.Mvc;

namespace IdeaPortal.Controllers
{
    public class EmployeeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
