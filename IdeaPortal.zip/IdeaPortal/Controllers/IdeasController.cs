﻿using Microsoft.AspNetCore.Mvc;
using IdeaPortal.Models;
using IdeaPortal.Data;
using Microsoft.EntityFrameworkCore;

namespace IdeaPortal.Controllers
{
    public class IdeasController : Controller
    {
        private readonly DatabaseContext dbContext;

        public IdeasController(DatabaseContext dbContext)
        {
            this.dbContext = dbContext;
        }
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var ideas = await dbContext.Ideas.ToListAsync();
            return View(ideas);
        }
        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Add(NewIdeaViewModel newIdeaRequest)
        {
            var idea = new Idea()
            {
                Id = Guid.NewGuid(),
                Description = newIdeaRequest.Description,
                Problem_Statement = newIdeaRequest.Problem_Statement,
                Proposed_Solution = newIdeaRequest.Proposed_Solution,
                Type = newIdeaRequest.Type,
                //hardcoded lol
                Status = "Pending",
                Validation = "Unique",
                Savings_Anthem = newIdeaRequest.Savings_Anthem,
                Savings_Carelon = newIdeaRequest.Savings_Carelon,
            };

            await dbContext.Ideas.AddAsync(idea);
            await dbContext.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> View(Guid Id)
        {
            var idea = await dbContext.Ideas.FirstOrDefaultAsync(x => x.Id == Id);
            if(idea != null)
            {
                var viewModel = new UpdateIdeaViewModel()
                {
                    Id = idea.Id,
                    Description = idea.Description,
                    Problem_Statement = idea.Problem_Statement,
                    Proposed_Solution = idea.Proposed_Solution,
                    Type = idea.Type,
                    Status = idea.Status,
                    Validation = idea.Validation,
                    Savings_Anthem = idea.Savings_Anthem,
                    Savings_Carelon = idea.Savings_Carelon,
                };
                return await Task.Run(() => View("View", viewModel));
            }

            return RedirectToAction("Index");
        }

        [HttpPost]
        public async Task<IActionResult> View(UpdateIdeaViewModel model)
        {
            var idea = await dbContext.Ideas.FindAsync(model.Id);

            if(idea != null)
            {
                idea.Description = model.Description;
                idea.Problem_Statement  = model.Problem_Statement;
                idea.Problem_Statement = model.Proposed_Solution;
                idea.Type = model.Type;
                idea.Status = model.Status; 
                idea.Validation = model.Validation; 
                idea.Savings_Anthem = model.Savings_Anthem;
                idea.Savings_Carelon = model.Savings_Carelon;

                await dbContext.SaveChangesAsync();

                return RedirectToAction("Index");
            }
            return RedirectToAction("Index");
        }

        [HttpPost]
        public async Task<IActionResult> Delete(UpdateIdeaViewModel model)
        {
            var idea = await dbContext.Ideas.FindAsync(model.Id);

            if(idea != null) { 
                dbContext.Ideas.Remove(idea);
                await dbContext.SaveChangesAsync();

                return RedirectToAction("Index");
            }

            return RedirectToAction("Index");
        }
    }
}
