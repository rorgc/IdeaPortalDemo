﻿using IdeaPortal.Models;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace IdeaPortal.Data
{
    public class DatabaseContext : DbContext
    {
        public DatabaseContext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<Idea> Ideas { get; set; }

        public DbSet<User> Users { get; set; }  
    }
}
