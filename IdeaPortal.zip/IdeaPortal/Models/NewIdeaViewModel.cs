﻿namespace IdeaPortal.Models
{
    public class NewIdeaViewModel
    { 
        public string Description { get; set; }
        public string Problem_Statement { get; set; }
        public string Proposed_Solution { get; set; }
        public string Type { get; set; }  //whether new system/improvement
        public string Status { get; set; }
        public string Validation { get; set; }
        public long Savings_Anthem { get; set; }
        public long Savings_Carelon { get; set; }
    }
}
