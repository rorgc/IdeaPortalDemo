﻿using System.ComponentModel.DataAnnotations;

namespace IdeaPortal.Models
{
    public class User
    {
        [Key]
        public string DomainId { get; set; }

        public string Name { get; set; }

        public string Department { get; set; }  

        public bool isTeamLead { get; set; }

        public bool isManager { get; set; } 

    }
}
